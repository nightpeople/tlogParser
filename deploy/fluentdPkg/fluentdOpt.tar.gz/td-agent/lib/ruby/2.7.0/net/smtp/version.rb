module Net
  class Protocol; end
  class SMTP < Protocol
    VERSION = "0.1.0"
  end
end
